"use strict";
//Importa la libreria express
const express = require("express");
//Parsear el contenido a JSON
const bodyParser = require("body-parser");
const cors = require("cors");
// Importa la libreria de mongoose
const mongoose = require("mongoose");
const crypto = require('crypto');

// Instancia el framework express
const app = express();
//Parsea los datos a json
app.use(bodyParser.json());

//Middleware
app.use(cors())
const Producto = require("./src/modelos/prodModelo");
const User = require("./src/modelos/usuModelo");
var prodNom, prodPrecio, prodStock;

app.post("/login", (req, res) => {
    const { usu, pass } = req.body //{ usu: "admin", pass:"1234" }
    const passCifrado = crypto.createHash('sha256').update(pass).digest('hex');
    User.findOne({ usuario: usu, password: passCifrado }, (error, dataUsu) => {
        if (error) {
            return res.send({ msg: "Error al loguearse", estado: "error" })
        } else {
            if (dataUsu !== null) {
                return res.send({ estado: "ok", url: "/producto" })
            }
        }
        return res.send({ msg: "Error al loguearse", estado: "error" })
    })
})

app.post("/producto/guardar", (req, res) => {
    const data = req.body

    //Instrucciones para guardar en BD
    const prod = new Producto(data);
    prod.save((error) => {
        if (error) {
            return res.send({ msg: "Error al guardar", estado: "error" })
        }
        return res.send({ msg: "Guardado con éxito", estado: "ok" })
    });
})

app.post("/producto/list", (req, res) => {
    Producto.find({}, (error, prod) => {
        if (error) {
            return res.send({ estado: "error", msg: "ERROR: AL buscar" })
        } else {
            if (prod !== null) {
                return res.send({ estado: "ok", msg: "ok", data: prod })
            } else {
                return res.send({ estado: "error", msg: "Sin productos" })
            }
        }
    })
})

app.post("/producto/get", (req, res) => {
    const { nombre } = req.body

    Producto.find({ nombre }, (error, prod) => {
        if (error) {
            return res.send({ estado: "error", msg: "ERROR: AL buscar" })
        } else {
            if (prod !== null) {
                return res.send({ estado: "ok", msg: "ok", data: prod })
            } else {
                return res.send({ estado: "error", msg: "Producto NO encontrado" })
            }
        }
    })
})

app.post("/producto/delete", (req, res) => {
    const { id } = req.body

    Producto.deleteOne({ _id: id }, (error) => {
        if (error) {
            return res.send({ estado: "error", msg: "ERROR: AL Eliminar" })
        } else {
            return res.send({ estado: "ok", msg: "Borrado con éxito" })
        }
    })
})

/**
 * Ruta: /producto/update
 * Metodo: POST
 * Headers: {content-type:application/json}
 * Body: {nombre:"papa", precio:2000, stock:100}
 */
app.post("/producto/update", (req, res) => {
    //Obtiene los datos del producto (desestructura)
    const { id, nombre, precio, stock } = req.body

    //Se usa el modelo Producto
    Producto.updateOne({ _id: id }
        , {
            $set:
            {
                nombre,
                precio,
                stock,
            }
        })
        .exec(
            (error, result) => {
                if (!error) {
                    //Si modifico un documento
                    if (result.modifiedCount > 0)
                        return res.send({ estado: "ok", msg: "Producto actualizado :)" });
                    return res.send({ estado: "error", msg: "Producto NO modificado :(" });
                }
                return res.send({ estado: "error", msg: "Error al actualizar :<" });
            }
        );
})

//Se conecta a BD mongodb
mongoose.connect("mongodb+srv://rperez:facil123456@cluster0.3nhnv.mongodb.net/tienda?retryWrites=true&w=majority")
    .then(res => console.log("Conectado a BD"))
    .catch(err => console.log(err))

app.listen(8000, () => {
    console.log(`Server is running on port 8000.`);
});