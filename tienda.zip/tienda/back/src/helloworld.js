export const sayHi = () => {
  console.log('Hola mundo!');
};
