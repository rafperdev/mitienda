import { useEffect, useState } from "react"

export function ProductoList() {
    //Crea una variable estado 
    //para guardar la lista de Productos
    const [listado, setListado] = useState([])

    useEffect(() => {
        fetch("http://localhost:8000/producto/list", {
            headers: {
                "content-type": "application/json"
            },
            method: "post",
        }).then(res => res.json())
            .then(res => {
                if (res.estado === "ok") {
                    setListado(res.data);
                }
            })
    },[])

    return (
        <table className="table">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Stock</th>
                </tr>
            </thead>
            <tbody>
                {
                    listado.map(p => <tr key={p.nombre}>
                        <td>{p.nombre}</td>
                        <td>{p.precio}</td>
                        <td>{p.stock}</td>
                    </tr>)
                }
            </tbody>
        </table>
    )
}