export default function Registrar() {
    return(
        <h1>Registrarse</h1>
    )
}