import { useRef } from "react"
import { Link } from "react-router-dom";

export default function Login() {
    //Crea dos Hooks de referencia para manipular los inputs de usuario y password
    const usuarioRef = useRef();
    const passwordRef = useRef();

    //Función para enviar los datos al servidor
    function login() {
        //Captura usuario/password
        const usu = usuarioRef.current.value;
        const pass = passwordRef.current.value;

        //Promesa fetch para consumir una api
        fetch("http://localhost:8000/login", {
            headers: { "content-type": "application/json" },
            method: "POST",
            body: JSON.stringify({ usu, pass })
        }).then(res => res.json())
            .then(res => {
                if (res.estado === "ok") {
                    window.location.href = res.url;
                } else {
                    alert("Error: Usuario/Password incorrectos")
                }
            })
    }

    return (
        <form>
            <div className="mb-3">
                <label for="exampleInputEmail1" className="form-label">Username</label>
                <input ref={usuarioRef} type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
            </div>
            <div className="mb-3">
                <label for="exampleInputPassword1" className="form-label">Password</label>
                <input ref={passwordRef} type="password" className="form-control" id="exampleInputPassword1" />
            </div>
            <button onClick={login} type="button" className="btn btn-primary">Submit</button>
            <Link to={"/registrarse"}>Registrarse</Link>
        </form>
    )
}