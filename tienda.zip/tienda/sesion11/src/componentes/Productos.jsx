import { useRef, useState } from "react"
import { Link } from "react-router-dom";

export default function Productos() {
    const nomRef = useRef();
    const preRef = useRef();
    const stoRef = useRef();
    const idRef = useRef();
    const [exito, setExito] = useState(false);

    function guardar() {
        //Capturar los datos a guardar
        const nombre = nomRef.current.value;
        const precio = preRef.current.value;
        const stock = stoRef.current.value;
        const id = idRef.current.value;

        fetch("http://localhost:8000/producto/guardar", {
            headers: {
                "content-type": "application/json", //TIPO MIME
            },
            method: "POST",
            body: JSON.stringify({ nombre, precio, stock, id })
        })
            .then(data => data.json())
            .then(res => {
                if (res.estado == "ok") {
                    setExito(true);
                    limpiar();
                }
            })
            .catch(err => alert(err))
            .finally()
    }

    function consultar() {
        const nombre = nomRef.current.value;
        fetch("http://localhost:8000/producto/get", {
            headers: {
                "content-type": "application/json", //TIPO MIME
            },
            method: "POST",
            body: JSON.stringify({ nombre })
        })
            .then(res => res.json())
            .then(res => {
                if (res?.estado === "error") {
                    alert(res.msg);
                } else {
                    preRef.current.value = res.data[0].precio;
                    stoRef.current.value = res.data[0].stock;
                    idRef.current.value = res.data[0]._id;
                }
            })
    }

    function borrar() {
        const resp = confirm("Realmente desea eliminar el Producto?");
        if (resp) {
            const id = idRef.current.value;
            fetch("http://localhost:8000/producto/delete", {
                headers: {
                    "content-type": "application/json", //TIPO MIME
                },
                method: "POST",
                body: JSON.stringify({ id })
            })
                .then(res => res.json())
                .then(res => {
                    alert(res.msg);
                })
        }
    }

    function editar() {
        const nombre = nomRef.current.value;
        const precio = preRef.current.value;
        const stock = stoRef.current.value;
        const id = idRef.current.value;
        fetch("http://localhost:8000/producto/update", {
            headers: {
                "content-type": "application/json", //TIPO MIME
            },
            method: "POST",
            body: JSON.stringify({ nombre, precio, stock, id })
        })
            .then(res => res.json())
            .then(res => {
                alert(res.msg);
            })

    }

    function limpiar() {
        nomRef.current.value = ""
        preRef.current.value = ""
        stoRef.current.value = ""
    }
    return (
        <form action="">
            {exito && <div className="alert alert-primary" role="alert"> Producto guardado :)</div>}
            <input ref={idRef} type="hidden" name="" />
            <label for="" className="form-label">Nombre</label>
            <input ref={nomRef} type="text" className="form-control" />
            <label for="" className="form-label">Precio</label>
            <input ref={preRef} type="text" className="form-control" />
            <label for="" className="form-label">Stock</label>
            <input ref={stoRef} type="text" className="form-control" />
            <Link to="/producto/listar">Listar</Link>
            <button type="button" onClick={guardar} className="btn btn-primary">Guardar</button>
            <button type="button" onClick={consultar} className="btn btn-primary">Consultar</button>
            <button type="button" onClick={editar} className="btn btn-primary">Editar</button>
            <button type="button" onClick={borrar} className="btn btn-primary">Borrar</button>
        </form>
    )
}