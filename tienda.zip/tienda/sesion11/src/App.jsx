import { useState } from 'react'
import reactLogo from './assets/react.svg'
import './App.css'
import Login from './componentes/Login'
import Productos from './componentes/Productos'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { ProductoList } from './componentes/ProductoList'
import Registrar from './componentes/Registrar'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Login />} />
        <Route path='/producto' element={<Productos />} />
        <Route path='/producto/listar' element={<ProductoList />} />
        <Route path='/registrarse' element={<Registrar />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
